from __main__ import pygame,Game,player,screen,UI,groups
import __main__ as main
import inspect,datas
objects=__import__("objects",fromlist=['*'])
check="动车"
conditions=datas.conditions
executions=datas.executions
class Window():
    def __init__(self):
        #screen = pygame.display.set_mode((1200, 800), pygame.RESIZABLE)
        self.UIs,self.objectlist,changelist={},{},{}
        self.variables=["请选择"]
        self.page,self.changeindex,self.chosen,self.choosing=0,0,0,0
        self.choose=Choose()
        self.comment=Comment()
        self.UIs["参数"]=UI.Text("参数",(0,0),"测试一下",page=1)
        self.board=UI.Board("编辑框",(1000,0),(1000,800),{},"#ffaaaa",page=None)
        self.board.AddUI(UI.Text("场景数",(0,0),"",wordsize=20,size=(200,20),page=None))
        self.board.AddUI(UI.Button("刷新",(0,20),(100,20),Game.Reimport,"#dce1b8",page=None))
        self.board.AddUI(UI.Text("刷新文字",(0,20),"刷新",size=(100,20),wordsize=14,page=None))
        self.board.AddUI(UI.Button("保存",(100,20),(100,20),Save,(255,255,125),page=None))
        self.board.AddUI(UI.Text("保存文字",(100,20),"保存",size=(100,20),wordsize=14,page=None))
        self.board.AddUI(UI.Button("添加",(0,40),(100,20),self.comment.AddComment,(0,255,0),page=None))
        self.board.AddUI(UI.Text("添加文字",(0,40),"添加",wordsize=14,size=(100,20),page=None))
        self.board.AddUI(UI.Button("删除",(100,40),(100,20),self.comment.DeleteIndex,(255,0,0),page=None))
        self.board.AddUI(UI.Text("删除文字",(100,40),"删除",wordsize=14,size=(100,20),page=None))
        self.board.AddUI(UI.Button("确定",(0,60),(100,20),self.OK,(125,255,125),page=None))
        self.board.AddUI(UI.Text("确定文字",(0,60),"确定",size=(100,20),wordsize=14,page=None))
        self.board.AddUI(UI.Button("取消",(100,60),(100,20),self.Cancel,(255,125,125),page=None))
        self.board.AddUI(UI.Text("取消文字",(100,60),"取消",size=(100,20),wordsize=14,page=None))
        self.board.AddUI(UI.Button("条件",(0,80),(200,20),self.Condition,"#feddb6",page=None))
        self.board.AddUI(UI.Text("条件文字",(0,80),"呱呱呱",wordsize=18,size=(200,20),page=None))
        self.board.AddUI(UI.Button("执行",(0,100),(200,20),self.Execution,"#feddb6",page=None))
        self.board.AddUI(UI.Text("执行文字",(0,100),"呱呱呱",wordsize=18,size=(200,20),page=None))
        self.board.AddUI(UI.PullDown("选择",(0,140),(200,20),["呱呱呱"],20,page=None))
        self.board.AddUI(UI.TextInput("输入框",(0,120),(200,20),"这里输入代码",page=None))
    def Update(self,event):
        if event:
            self.board.Update(event)
        self.board.Draw()
        Draw()
        self.choose.Update()
        objectlist=[]
        self.board.value["场景数"].value=f"--*[场 景 {Game.level}]*--"
        if event.type==pygame.MOUSEBUTTONDOWN:
            if pygame.mouse.get_pos()[0]<1000:
                self.objectlist=self.choose.FindObjects()
                if self.objectlist:
                    self.board.value["选择"].value=[list(self.objectlist.keys())[0],*self.objectlist.keys()]
                else:
                    self.board.value["条件文字"].value="可是"
                    self.board.value["执行文字"].value="这里没东西"
                    self.board.value["选择"].value=["这里没东西"]
        elif event.type==pygame.KEYDOWN and event.key==pygame.K_DELETE:
            screen = pygame.display.set_mode((1000,800))
            main.openeditor=0
        keys = main.pygame.key.get_pressed()
        if keys[main.pygame.K_f]:
            Game.view[0]+=1
        if keys[main.pygame.K_h]:
            Game.view[0]-=1
        if keys[main.pygame.K_t]:
            Game.view[1]+=1
        if keys[main.pygame.K_g]:
            Game.view[1]-=1
        if keys[main.pygame.K_o]:
            Game.level-=1
            objects.Delete()
            self.Load()
        if keys[main.pygame.K_p]:
            Game.level+=1
            objects.Delete()
            self.Load()
        if self.page:
            self.board.value["选择"].value=self.variables
            self.chosen=self.board.value["选择"].value[0]
            if self.choosing==1:
                self.board.value["条件文字"].value=self.board.value["选择"].value[0]
            elif self.choosing==2:
                self.board.value["执行文字"].value=self.board.value["选择"].value[0]
        elif self.board.value["选择"].value[0]!=self.chosen:
            self.chosen=self.board.value["选择"].value[0]
            if self.chosen in self.objectlist:
                self.board.value["条件文字"].value="元素名称"
                self.board.value["执行文字"].value=self.chosen
                if list(self.choose.ObjectFunctions(self.objectlist[self.chosen]).keys()):
                    self.comment.Load(self.objectlist[self.chosen])
                else:self.comment.Load()
    def OK(self):
        if self.page:
            self.page=not self.page
            self.board.value["选择"].value=[list(self.objectlist.keys())[0],*self.objectlist.keys()]
            exec(f'''global key,value
key=lambda self:{self.board.value['条件文字'].value}
value=lambda self:{self.board.value['执行文字'].value}''')
            print(type(key),type(value))
            list(self.objectlist.values())[self.changeindex].trigger[key]=[value]
    def Cancel(self):
        if self.page:
            self.page=not self.page
            self.board.value["选择"].value=[list(self.objectlist.keys())[0],*self.objectlist.keys()]
    def OnChangeLevel(self):
        self.linelist=CheckFile()
    def Changing(self,index):
        self.page=not self.page
        self.changeindex=index
        self.board.value["条件文字"].value=list(self.comment.commentlist[index].keys())[0]
        self.board.value["执行文字"].value=list(self.comment.commentlist[index].values())[0]
        while len(self.comment.showlist):
            self.comment.Clear()
    def Condition(self):
        if self.page:
            self.choosing=1
            self.variables=[list(self.comment.commentlist[self.changeindex].keys())[0],*list(conditions.values())]
    def Execution(self):
        if self.page:
            self.choosing=2
            self.variables=[list(self.comment.commentlist[self.changeindex].values())[0],*list(executions.values())]
class Comment:
    def __init__(self):
        self.commentlist,self.showlist=[],[]
    def Load(self,obj=False):
        while len(self.showlist):
            self.Clear()
        if obj:
            data=list(window.choose.ObjectFunctions(obj).keys())
            for i in data:
                try:
                    i=list(inspect.getsource(i).replace("/n","").split(":"))
                except:
                    i=["","hiddenaa","","hiddenaaaa"]
                self.AddComment({i[1][:-2]:i[3][:-4]})
    def AddComment(self,comment={lambda:None:lambda:None},index=-1):
        self.commentlist.insert(index,comment)
        self.showlist.insert(index,comment)
        if index<=len(self.showlist):
            for key,value in comment.items():
                window.board.AddUI(UI.Button(f"button{len(self.showlist)}",(0,120+20*len(window.board.value["选择"].value)+20*len(self.showlist)),(200,20),lambda:window.Changing(index),(255,125,125),page=None))
                window.board.AddUI(UI.Text(len(self.showlist),(0,120+20*len(window.board.value["选择"].value)+20*len(self.showlist)),f"如果{key}那么{value}",(125,255,125),wordsize=20,page=None))
    def DeleteIndex(self,index=-1):
        if index<=len(self.commentlist):
            if len(self.commentlist):
                self.Clear()
                self.commentlist.pop(index)
    def Clear(self):
        if len(self.showlist):
            del window.board.value[len(self.showlist)]
            del window.board.value[f"button{len(self.showlist)}"]
            self.showlist.pop()
    '''def Change(self):
        window.UIs["执行文字"]=self.commentlist[window.changeindex]
        for key,value in comment.items():
            window.board.value[index].value=f"如果{key}那么{value}"'''
def CheckFile():
    linelist=[]
    file=open(f"levels\\{levelmoudles[Game.level]}.py","rb")
    for line in file:
        linelist.append(line)
    return linelist
class Choose(pygame.sprite.Sprite):
    def __init__(self):
        global group
        super().__init__()
        self.group=pygame.sprite.Group(self)
        self.rect=pygame.rect.Rect(0,0,40,40)
    def Update(self):
        x,y=pygame.mouse.get_pos()
        self.rect.topleft =x-x%40,y-y%40
        pygame.draw.rect(screen,(0,0,0),self.rect,1)
    def FindObjects(self):
        objectlist={}
        i=0
        for group in groups.values():
            colliders=pygame.sprite.spritecollide(self,group,0)
            if colliders:
                for collider in colliders:
                    i+=1
                    objectlist[collider.name]=collider
        return objectlist
    def ObjectFunctions(self,objects):
        return objects.trigger
def Draw():
    for i in range(20):
        pygame.draw.line(screen,(255,255,0),(0,i*40),(1000,i*40),1)
    for i in range(25):
        pygame.draw.line(screen,(255,255,0),(i*40,0),(i*40,800),1)
def Save():
    pass
def Update(event):
    window.Update(event)
window=Window()
"""
这是i wanna 的编辑器
"""

import sys,animation
import __main__ as main
sys.path.append("objects")
objects=__import__("objects",fromlist=['*'])
check="cb0f6ec3877cca8fbff7866761f29626"
def Init():
    Save((1,18),{})
    Save((12,4),{})
    for x in range(25):
        Ground((x,19),{})
    for x in range(25):
        Trap((x,-2) if game.stage<3 else (x,0),{lambda self:self.xy[1]!=0 and player.xy[1]<1:[lambda self:events.MoveTo(self,["",0])],
                    lambda self:game.stage>3 and player.xy[0]>self.xy[0] and player.xy[0]<self.xy[0]+1:[lambda self:events.MoveTo(self,["",20],3000,a=2),
                                                                                      lambda self:events.MoveTo(self,[24,""],3000,[25,""],a=1/2),"save"]},rotation=90)

    for y in range(7):
        Ground((-1,15-y) if game.stage<3 else (0,15-y),{lambda self:game.stage==5 and player.xy[1]>self.xy[1] and player.xy[1]<self.xy[1]+1:[lambda self:events.MoveTo(self,[24,""],10000,a=1),
                                                                                                               lambda self:events.MoveTo(self,[0,""],1000,[-1,""],a=1/2),"save"]})
    for y in range(18):
        Ground((25,18-y),{lambda self:game.stage==5 and player.xy[0]>20:[lambda self:events.MoveTo(self,[13,""],5000,a=2),
                                                       lambda self:events.MoveTo(self,["","-2"],500,a=1/2),
                                                       lambda self:events.MoveTo(self,["","+2"],500,a=2),
                                                       lambda self:events.MoveTo(self,[-1,""],1000,a=2)]})
def Update(event):
    pass
def OnOutOfScreen(direction):
    if direction!="right":
        game.OnDeath()
    else:
        import __main__ as main
        game.OnWin()
        player.moveable=(0,0)
def Oncollision(collider,globalpoint):
    pass
def Reset():
    Delete()
def Funcs(self,number):
    global stage
    match number:
        case 0:self.xy[0]-=1/50
def Check(self,number):
    match number:
        case 0:return (player.xy[0]<1 or self.xy[0]!=1 )and self.xy[0]>0

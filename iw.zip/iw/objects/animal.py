import __main__ as main
originimage=b"images\\animal.png"
istrigger=1
index=2
variable="speed=1"
supplement="self.speed,self.img,self.vertically=[speed,0],image,1"
def Update(self):
    self.jumptwice=1
    self.speed[1]-=1/100
    self.rect[0]+=self.speed[0]
    self.rect[1]-=self.speed[1]
    for group in main.groups.values():
        colliders=main.pygame.sprite.spritecollide(self,group,0)
        if colliders:
            for collider in colliders:
                self.OnCollision(collider)
                collider.OnCollision(self)
    self.xy=[self.rect[0]/40,self.rect[1]/40]
    if self.vertically*self.speed[0]<0:
        self.ImgUpdate(self,flip=[1,0])
        self.vertically*=-1
def OnCollision(self,collider):
    point=main.pygame.sprite.collide_mask(self,collider)
    rect=self.rect.union(collider.rect).clip(self.rect).clip(collider.rect)
    if point:
        globalpoint=self.xy[0]+point[0],self.xy[1]+point[1]
        if not collider.istrigger:
            self.highdata=0
            if rect[2]>rect[3]:
                if self.xy[1]<collider.xy[1]:
                    self.speed[1]=0
                    #self.speed[1]=5
                    self.rect.bottom = collider.rect.top+1
                    if collider == main.player:
                        main.Game.OnDeath()
                else:
                    self.rect.top = collider.rect.bottom
                    if collider == main.player:
                        main.player.speed[1]=1/20
                        self.Delete()
            else:
                if self.xy[0]<collider.xy[0]:
                    self.rect.right = collider.rect.left
                    if collider == main.player:
                        main.Game.OnDeath()
                    else:
                        self.speed[0]=-self.speed[0]
                else:
                    self.rect.left = collider.rect.right
                    if collider == main.player:
                        main.Game.OnDeath()
                    else:
                        self.speed[0]=-self.speed[0]

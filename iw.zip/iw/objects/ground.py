originimage=b"images\\ground.png"
istrigger=0
variable=""
index=5
supplement=""
def OnCollision(self,collider):
    pass
def Update(self):
    pass
